# CFS v17 Production Package

This ZIP contains everything needed to run the v17 model in your own program.

## Files

- `cfs_v17_inference_bundle.joblib`: trained production model (one file).
- `cfs_v17_predict.py`: standalone Python module exposing `CFSV17Predictor`.
- `v16_holdout_predictions.csv`, `v16_pareto_candidate_report.csv`,
  `v16_error_by_design_group.csv`, `v16_error_by_true_FM_audit_only.csv`,
  `v16_repeated_cv_folds.csv`, `v16_repeated_cv_summary.json`,
  `v16_final_summary.json`, `v16_feature_report.json`,
  `v16_shap_importance.csv`: official audit results.
- `v16_scatter_holdout.png`, `v16_residuals_by_group.png`,
  `v16_shap_summary.png`: figures.
- `v16_model_bundle_holdout.joblib`: full pipeline bundle (audit only).

## Use in your program (1 minute setup)

```python
import pandas as pd
from cfs_v17_predict import CFSV17Predictor

predictor = CFSV17Predictor.load("cfs_v17_inference_bundle.joblib")
df = pd.read_csv("your_inputs.csv")
out = predictor.predict(df)
print(out.head())
```

Required input columns: SectionType, Sections, BC, L, t, h, b, A, Fy, Py,
Pcrl, Pne, KLr, lambda_c, lambda_led. (FM is NOT needed for prediction.)

## Or via the command line

```
python cfs_v17_predict.py cfs_v17_inference_bundle.joblib your_inputs.csv predictions.csv
```

## Note

The production inference model is a faithful distillation of the published
stacked pipeline. Reported pipeline metrics (TEST R², CV R²) are in
`v16_final_summary.json`. The inference model's training-set OOF R² and
test-set metrics are stored in the bundle as `training_oof_r2` and
`test_metrics`.
