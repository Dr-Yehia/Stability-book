"""
cfs_v17_predict.py
==================
Standalone, no-dependency-on-training-script predictor.

Usage (e.g. inside any external program with a UI):

    import joblib
    import pandas as pd
    from cfs_v17_predict import CFSV17Predictor

    predictor = CFSV17Predictor.load("cfs_v17_inference_bundle.joblib")
    df = pd.read_csv("new_specimens.csv")  # raw input columns
    out = predictor.predict(df)            # returns DataFrame with PtPy_pred
    print(out.head())

Required raw columns (same as the training CSV):
    SectionType (or "Section Types"), Sections, BC,
    L, t, h, b, A, Fy, Py, Pcrl (or "P(crl,crd)"), Pne,
    KLr (or "KL_r" / "KL/r"), lambda_c (or "λc"), lambda_led (or "λ(le-d)").
"FM" (true failure mode) is NOT required for prediction.
"""

import math
import re
import numpy as np
import pandas as pd
import joblib

EPS = 1e-12


def _safe_num(s):
    return pd.to_numeric(s, errors="coerce")


def _clean_text(s):
    return (
        s.fillna("Unknown").astype(str).str.strip()
         .replace({"": "Unknown", "nan": "Unknown", "None": "Unknown"})
    )


def _sdiv(a, b):
    a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
    return np.divide(a, np.where(np.abs(b) < EPS, np.nan, b))


def _dsm_global(lam):
    lc = np.asarray(lam, dtype=float)
    lc = np.where(lc <= 0, np.nan, lc)
    return np.where(lc <= 1.5, 0.658 ** (lc ** 2), 0.877 / (lc ** 2 + EPS))


def _dsm_local(lam, pne_py):
    lam = np.asarray(lam, dtype=float); pne = np.asarray(pne_py, dtype=float)
    lam = np.where(lam <= 0, np.nan, lam)
    reduction = np.where(
        lam <= 0.776,
        1.0,
        (1.0 - 0.15 / (lam ** 0.8 + EPS)) / (lam ** 0.8 + EPS),
    )
    return pne * reduction


def _assign_section_group(section_type, sections):
    st = str(section_type).strip()
    sec = str(sections).strip().lower()
    if st == "O-2C": return "G1_O2C"
    if st == "O-2U": return "G2_O2U"
    if st == "C-U+C": return "G3_CUC"
    if st.startswith("HC"): return "G4_HC"
    if st.startswith("C-2C") or st.startswith("C-2Σ") or st.startswith("C-2\u03a3"):
        return "G5_C2C"
    if st.startswith("O-"): return "G6_Open"
    if "closed" in sec or "box" in st.lower() or "-i-" in st.lower():
        return "G7a_Closed_Box"
    return "G7b_Rest"


def _engineer_features(df_raw):
    """Reproduce the full v17 feature engineering on raw inputs."""
    aliases = {
        "SectionType": ["SectionType", "Section Types", "Section_Type"],
        "Sections": ["Sections"],
        "BC": ["BC", "Boundary", "Boundary Condition"],
        "L": ["L"], "t": ["t"], "h": ["h"], "b": ["b"], "A": ["A"],
        "Fy": ["Fy"], "Py": ["Py"],
        "Pcrl": ["Pcrl", "P(crl,crd)", "Pcrl_crd"],
        "Pne": ["Pne"],
        "KLr": ["KLr", "KL_r", "KL/r"],
        "lambda_c": ["lambda_c", "λc", "lam_c"],
        "lambda_led": ["lambda_led", "λ(le-d)", "lam_led"],
    }
    df = pd.DataFrame(index=df_raw.index)
    for std_name, options in aliases.items():
        col = next((c for c in options if c in df_raw.columns), None)
        if col is None and std_name in ("Sections", "BC"):
            df[std_name] = "Unknown"
            continue
        if col is None:
            raise KeyError(f"Missing required column for {std_name}; tried {options}")
        if std_name in ("SectionType", "Sections", "BC"):
            df[std_name] = _clean_text(df_raw[col]).str.replace(r"\s+", "", regex=True)
        else:
            df[std_name] = _safe_num(df_raw[col])

    df["SG_design"] = [_assign_section_group(st, se) for st, se in zip(df["SectionType"], df["Sections"])]

    # geometry/material/buckling features (must mirror training)
    df["h_t"] = _sdiv(df["h"], df["t"])
    df["b_t"] = _sdiv(df["b"], df["t"])
    df["L_h"] = _sdiv(df["L"], df["h"])
    df["L_b"] = _sdiv(df["L"], df["b"])
    df["L_t"] = _sdiv(df["L"], df["t"])
    df["h_b"] = _sdiv(df["h"], df["b"])
    df["b_h"] = _sdiv(df["b"], df["h"])
    df["A_t2"] = _sdiv(df["A"], df["t"] ** 2)
    df["sqrt_A_t"] = _sdiv(np.sqrt(np.abs(df["A"])), df["t"])
    df["Fy_E"] = df["Fy"] / 203000.0
    df["Fy_norm"] = df["Fy"] / 350.0
    df["Pcrl_Py"] = _sdiv(df["Pcrl"], df["Py"])
    df["Pne_Py"] = _sdiv(df["Pne"], df["Py"])
    df["Pcrl_Pne"] = _sdiv(df["Pcrl_Py"], df["Pne_Py"])
    df["Pne_Pcrl"] = _sdiv(df["Pne_Py"], df["Pcrl_Py"])
    df["lambda_c_sq"] = df["lambda_c"] ** 2
    df["lambda_c_cu"] = df["lambda_c"] ** 3
    df["lambda_led_sq"] = df["lambda_led"] ** 2
    df["lambda_led_cu"] = df["lambda_led"] ** 3
    df["inv_lambda_c"] = _sdiv(1.0, df["lambda_c"])
    df["inv_lambda_led"] = _sdiv(1.0, df["lambda_led"])
    df["lambda_c_over_led"] = _sdiv(df["lambda_c"], df["lambda_led"])
    df["lambda_led_over_c"] = _sdiv(df["lambda_led"], df["lambda_c"])
    df["lambda_c_led"] = df["lambda_c"] * df["lambda_led"]
    df["lambda_c_KLr"] = df["lambda_c"] * df["KLr"]
    df["lambda_c_Pne"] = df["lambda_c"] * df["Pne_Py"]
    df["lambda_led_Pcrl"] = df["lambda_led"] * df["Pcrl_Py"]
    df["Pne_Pcrl_product"] = df["Pne_Py"] * df["Pcrl_Py"]
    df["h_t_b_t"] = df["h_t"] * df["b_t"]
    df["lambda_c_h_t"] = df["lambda_c"] * df["h_t"]
    df["lambda_c_b_t"] = df["lambda_c"] * df["b_t"]
    df["Pcrl_sq"] = df["Pcrl_Py"] ** 2
    df["Pne_sq"] = df["Pne_Py"] ** 2
    df["sqrt_Pcrl"] = np.sqrt(np.abs(df["Pcrl_Py"]))
    df["sqrt_Pne"] = np.sqrt(np.abs(df["Pne_Py"]))
    df["DSM_global"] = _dsm_global(df["lambda_c"])
    df["DSM_local"] = _dsm_local(df["lambda_led"], df["Pne_Py"])

    bc = pd.DataFrame({
        "DSM_global": df["DSM_global"], "DSM_local": df["DSM_local"],
        "Pne_Py": df["Pne_Py"], "Pcrl_Py": df["Pcrl_Py"],
    }).replace([np.inf, -np.inf], np.nan)
    bc = bc.where(bc > 0)
    df["base_global"] = df["DSM_global"]
    df["base_local"] = df["DSM_local"]
    df["base_pne"] = df["Pne_Py"]
    df["base_pcrl"] = df["Pcrl_Py"]
    df["base_min"] = bc.min(axis=1)
    df["base_mean"] = bc.mean(axis=1)
    df["base_geom"] = np.sqrt(np.maximum(df["base_min"], 0.02) * np.maximum(df["base_mean"], 0.02))

    for b in ["base_global","base_local","base_pne","base_pcrl","base_min","base_mean","base_geom"]:
        df[b] = pd.Series(df[b]).replace([np.inf,-np.inf], np.nan).fillna(df["base_mean"]).clip(0.02, 1.30)

    df["DSM_global_local_ratio"] = _sdiv(df["DSM_global"], df["DSM_local"])
    df["DSM_spread_abslog"] = np.abs(np.log(np.maximum(df["DSM_global"],0.02)/np.maximum(df["DSM_local"],0.02)))
    df["Pne_DSM_global"] = _sdiv(df["Pne_Py"], df["DSM_global"])
    df["Pcrl_DSM_global"] = _sdiv(df["Pcrl_Py"], df["DSM_global"])
    df["min_global_local"] = pd.DataFrame({"g": df["Pne_Py"], "l": df["Pcrl_Py"]}).min(axis=1)
    df["max_global_local"] = pd.DataFrame({"g": df["Pne_Py"], "l": df["Pcrl_Py"]}).max(axis=1)
    df["range_global_local"] = df["max_global_local"] - df["min_global_local"]

    df["region_short"] = (df["lambda_c"] < 0.7).astype(float)
    df["region_intermediate"] = ((df["lambda_c"] >= 0.7) & (df["lambda_c"] <= 1.3)).astype(float)
    df["region_slender"] = (df["lambda_c"] > 1.3).astype(float)
    df["is_open_section"] = df["Sections"].astype(str).str.lower().str.contains("open").astype(float)
    df["is_closed_section"] = df["Sections"].astype(str).str.lower().str.contains("closed").astype(float)
    df["is_half_closed_section"] = df["Sections"].astype(str).str.lower().str.contains("half").astype(float)

    for c in df.select_dtypes(include=np.number).columns:
        med = df[c].replace([np.inf,-np.inf], np.nan).median()
        df[c] = df[c].replace([np.inf,-np.inf], np.nan).fillna(med if np.isfinite(med) else 0.0)
    return df


def _make_classifier_matrix(df, num_features_base, cat_features, fm_oh_cols):
    X = pd.DataFrame(index=df.index)
    for c in num_features_base:
        X[c] = df[c].astype(float).values if c in df.columns else 0.0
    oh = pd.get_dummies(df[cat_features].astype(str), prefix=cat_features, dtype=float)
    for c in fm_oh_cols:
        if c not in oh.columns:
            oh[c] = 0.0
    X = pd.concat([X, oh[fm_oh_cols]], axis=1)
    return X.replace([np.inf,-np.inf], np.nan).fillna(0.0).astype(float)


def _apply_fm_classifiers(df, classifiers, fm_classes, num_features_base, cat_features, fm_oh_cols):
    if not classifiers or not fm_classes:
        return df
    X_clf = _make_classifier_matrix(df, num_features_base, cat_features, fm_oh_cols)
    n_classes = len(fm_classes)
    accum = np.zeros((len(df), n_classes))
    used = 0
    for entry in classifiers:
        try:
            m = entry["model"]
            p = m.predict_proba(X_clf)
            aligned = np.zeros((len(df), n_classes))
            for j, cls in enumerate(m.classes_):
                aligned[:, int(cls)] = p[:, j]
            accum += aligned
            used += 1
        except Exception:
            pass
    if used == 0:
        return df
    probs = accum / used
    for i, cls in enumerate(fm_classes):
        safe_cls = re.sub(r"[^A-Za-z0-9]+", "_", str(cls)).strip("_")
        df[f"FMprob_{safe_cls}"] = probs[:, i]
    df["FMprob_max"] = probs.max(axis=1)
    df["FMprob_entropy"] = -np.sum(probs * np.log(probs + EPS), axis=1)
    return df


def _add_fm_interactions(df):
    def find_prob_col(name):
        target = f"FMprob_{name}"
        if target in df.columns:
            return target
        for c in df.columns:
            if c.startswith("FMprob_") and c.split("FMprob_")[-1].upper() == name.upper():
                return c
        return None

    is_g5 = (df["SG_design"].astype(str).values == "G5_C2C").astype(float)
    pf_col = find_prob_col("F"); pldf_col = find_prob_col("LDF")

    if pf_col is not None:
        pF = df[pf_col].astype(float).values
        df["FMint_PF"] = pF
        df["FMint_G5C2C_x_PF"] = is_g5 * pF
        df["FMint_PF_x_lambda_c"] = pF * df.get("lambda_c", 0.0).astype(float).values
        df["FMint_PF_x_Pcrl_Py"]  = pF * df.get("Pcrl_Py", 0.0).astype(float).values
        df["FMint_PF_x_Pne_Py"]   = pF * df.get("Pne_Py", 0.0).astype(float).values
        df["FMint_PF_x_DSM_local"] = pF * df.get("DSM_local", 0.0).astype(float).values
    if pldf_col is not None:
        pLDF = df[pldf_col].astype(float).values
        df["FMint_PLDF"] = pLDF
        df["FMint_G5C2C_x_PLDF"] = is_g5 * pLDF
    for c in [c for c in df.columns if c.startswith("FMint_")]:
        df[c] = pd.Series(df[c]).replace([np.inf,-np.inf], np.nan).fillna(0.0).values
    return df


def _build_strength_matrix(df, te_maps, te_global_mean, num_features_base, cat_features, str_oh_cols):
    X = pd.DataFrame(index=df.index)
    feature_pool = list(num_features_base)
    feature_pool += [c for c in df.columns if c.startswith("FMprob_") or c.startswith("FMint_")]
    for c in feature_pool:
        if c in df.columns:
            X[c] = df[c].astype(float).values
    for cat in cat_features:
        mapping = te_maps.get(cat, {})
        col = df[cat].astype(str).map(mapping).fillna(te_global_mean).values
        X[f"{cat}_te"] = col.astype(float)
    oh = pd.get_dummies(df[cat_features].astype(str), prefix=cat_features, dtype=float)
    for c in str_oh_cols:
        if c not in oh.columns:
            oh[c] = 0.0
    X = pd.concat([X, oh[str_oh_cols]], axis=1)
    return X.replace([np.inf,-np.inf], np.nan).fillna(0.0).astype(float)


class CFSV17Predictor:
    """Inference-only wrapper around the v17 production bundle."""

    def __init__(self, bundle):
        self.bundle = bundle

    @classmethod
    def load(cls, bundle_path):
        return cls(joblib.load(bundle_path))

    def predict(self, raw_df, return_engineered=False):
        b = self.bundle
        df = _engineer_features(raw_df)
        df = _apply_fm_classifiers(
            df, b.get("fm_classifiers", []), b.get("fm_classes", []),
            b["num_features_base"], b["cat_features"], b.get("fm_onehot_cols", []),
        )
        df = _add_fm_interactions(df)
        X = _build_strength_matrix(
            df, b["te_maps"], b["te_global_mean"],
            b["num_features_base"], b["cat_features"], b["strength_onehot_cols"],
        )
        # Align column order to training feature_cols
        for c in b["feature_cols"]:
            if c not in X.columns:
                X[c] = 0.0
        X = X[b["feature_cols"]]

        # Run all base regressors, blend, shrink, calibrate.
        base_preds = []
        for name, model in b["base_regressors"].items():
            try:
                base_preds.append(model.predict(X))
            except Exception:
                base_preds.append(np.full(len(X), b["te_global_mean"]))
        base_mat = np.column_stack(base_preds) if base_preds else np.zeros((len(X), 1))
        blended = b["ridge_blender"].predict(base_mat)
        shrunk = blended * b["shrink_factor"]
        shrunk = np.clip(shrunk, b["pred_min"], b["pred_max"])
        calibrated = b["isotonic_calibrator"].predict(shrunk)
        calibrated = np.clip(calibrated, b["pred_min"], b["pred_max"])

        out = pd.DataFrame({
            "PtPy_pred": calibrated,
            "PtPy_pred_uncalibrated": np.clip(blended, b["pred_min"], b["pred_max"]),
        }, index=raw_df.index)
        if "Py" in raw_df.columns:
            out["Pt_pred_kN"] = calibrated * pd.to_numeric(raw_df["Py"], errors="coerce").values
        if return_engineered:
            return out, df
        return out


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3:
        bundle_path, csv_path = sys.argv[1], sys.argv[2]
        out_path = sys.argv[3] if len(sys.argv) >= 4 else "predictions.csv"
        predictor = CFSV17Predictor.load(bundle_path)
        df_raw = pd.read_csv(csv_path)
        result = predictor.predict(df_raw)
        result.to_csv(out_path, index=False)
        print(f"Wrote: {out_path} ({len(result)} rows)")
    else:
        print("Usage: python cfs_v17_predict.py <bundle.joblib> <input.csv> [output.csv]")
